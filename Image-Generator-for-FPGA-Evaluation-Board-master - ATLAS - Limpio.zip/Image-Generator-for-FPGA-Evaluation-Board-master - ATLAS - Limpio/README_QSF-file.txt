README QSF-file

For pin asignments use file 
  DE10_LITE_Default.qsf 
provided with DE10-Lite board
